部署步骤
1. 解压到站点根目录
2. 确认 upload/ 可写（chmod 777 upload）
3. 后台入口 /login.php，初始账号见 config/db.php 注释里的运维账号
4. 补丁上传后直接按 /upload/<文件名> 访问
