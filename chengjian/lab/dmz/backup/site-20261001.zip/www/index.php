<?php // 旧版首页（2026-09），已被 v2.6 取代 ?>
<html><head><title>ACME 门户</title></head><body><h1>ACME Corp Portal</h1></body></html>
