<?php
// ACME portal - DB 连接配置（2026-09 迁移前版本）
return [
    'dsn'  => 'mysql://portal_user:Portal_2026!@db.internal:3306/portal',
    'user' => 'portal_user',
    'pass' => 'Portal_2026!',
    'charset' => 'utf8mb4',
];
